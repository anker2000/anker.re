function pad(n, width, z) {
  z = z || '0';
  n = n + '';
  return n.length >= width ? n : new Array(width - n.length + 1).join(z) + n;
}

function addDays(date, days) {
    var result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
}
function transformMatrixToArray(matrix) {
	var matrixArray = matrix.replace("matrix(","").replace(")","").split(",");
	return matrixArray;
}
function hasParentWithClass(obj, className) {
	if (obj.tagName=="BODY") {
		return false;
	}
	if ($(obj).hasClass(className)) {
		return true;
	} else {
		return hasParentWithClass(obj.parentNode,className);
	}
}
function parentWithTagName(obj, tagName) {
	if (obj.tagName=="BODY") {
		return false;
	}
	var objTagName=obj.tagName;
	if (objTagName.toLowerCase()==tagName.toLowerCase()) {
		return obj;
	} else {
		return parentWithTagName(obj.parentNode,tagName);
	}
}
function formatMinutes(min) {
	var hours = Math.floor(min/60);
	var minutes = min - hours * 60
	return hours +"h "+ minutes+"m";
}
function formatPrice(price) {
	var formattedPrice;
	if (price<0) {
		formattedPrice = "- £" +Math.abs(price).toFixed(2);
	} else {
		formattedPrice = "+ £" + price.toFixed(2);
	}
	return formattedPrice;
}
function clearAllIntervals(){
	if (typeof clearAllIntervals.last == 'undefined' ) {
    	clearAllIntervals.last = setTimeout("||void",0); // Opera || IE other browsers accept "" or "void"
    }
    var mx = setInterval("||void",0);
    for (var i=clearAllIntervals.last; i<=mx; i++) {
    	clearInterval(i);
    }
	clearAllIntervals.last = i;
}
clearAllIntervals();
function generateRandomNumb(min, max) {
    return Math.floor(Math.random() * (max - min) + min);
}
function addCSSRule(e) {
    -1 == $.inArray(e, dynamicCSSRules) && ($("head").append("<style>" + e + "</style>"), dynamicCSSRules.push(e))
}
function addCSSRule(rule) {
    if ($.inArray(rule, dynamicCSSRules) == -1) {
        $('head').append('<style>' + rule + '</style>');
        dynamicCSSRules.push(rule);
    }
}

$(".toggle .element").on("click", function() {
    $(this).parent().find(".element").removeClass("current");
    $(this).addClass("current");
    $(this).is(".right") ? ($("#jrange").addClass("double"), $("#calendar").addClass("double").removeClass("single")) : ($("#jrange").removeClass("double"), $("#calendar").addClass("single").removeClass("double"))
})