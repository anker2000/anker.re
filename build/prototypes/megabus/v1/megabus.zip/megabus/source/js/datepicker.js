var i = 0,
    j, widthDate, cellContents = [],
    numberTraveller = 1,
    numberCards = 0,
    locateTarget = !1,
    direction = "leaving",
    shortmonth = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
    weekday = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
    now = new Date;
now.setHours(0), now.setMinutes(0), now.setSeconds(0);
var sliderValues, saveTheDate = {
    leaving: now,
    returning: ""
};

$("#jrange.dates input.leaving").val("Today"), $(".date .direction .leaving .value").html("Today").addClass("validates");
var cellContents = [];
for (var i = 0; 170 > i; i++) {
    var numberIsInArray = !1,
        rand = generateRandomNumb(45, 50);
    cellContents.push("£" + rand)
}
function updateDatePickerCells(dp) {
    setTimeout(function () {

        $('.ui-datepicker td > *').each(function (idx, elem) {
            var value = cellContents[idx + 1] || 0;
            var className = 'datepicker-content-' + CryptoJS.MD5(value).toString();

            if (value == 0)
                addCSSRule('.ui-datepicker td a.' + className + ':after {content: "\\a0";}'); //&nbsp;
            else
                addCSSRule('.ui-datepicker td a.' + className + ':after {content: "' + value + '";}');

            $(this).addClass(className);
        });
    }, 10);
}
var dynamicCSSRules = [];


function roundRange() {
    $(".ui-datepicker td.date-range-selected").each(function(e, t) {
        0 == e && $(t).addClass("start"), e == $(".ui-datepicker td.date-range-selected").children().length - 1 && "" != saveTheDate.returning && $(t).addClass("end")
    })
}
function dateSingle(e) {
    console.log("date Single");
    direction = "leaving";
    $(".search_drawer .date").toggleClass("show");
    $(".search_drawer .date .direction .returning").removeClass("active");
    $(".search_drawer .date .direction .leaving").addClass("active");
    var t = $(".ui-datepicker td a").width();
    $(".ui-datepicker td a, .ui-state-highlight").height(t), updateDatePickerCells()
}

function dateDouble(e) {
    direction = "returning";
    $(".search_drawer .date").toggleClass("show");
    $(".search_drawer .date .direction .leaving").removeClass("active");
    $(".search_drawer .date .direction .returning").addClass("active");
    var t = $(".ui-datepicker td a").width();
    $(".ui-datepicker td a, .ui-state-highlight").height(t);
    enableContinueButton();
}
function removeTodayHighlighting() {
    $(".ui-datepicker td").removeClass(" ui-datepicker-current-day, date-range-selected, ui-datepicker-current-day")
}
function enableContinueButton() {
    $(".container.cta button").removeClass("outofreach")
}

function calendarDirection(e) {
    var t = e.target.parentNode;
    enableContinueButton(), $(t).hasClass("leaving") ? (direction = "leaving", $(".date .direction .returning").removeClass("active"), $(".date .direction .leaving").addClass("active")) : (direction = "returning", $(".date .direction .leaving").removeClass("active"), $(".date .direction .returning").addClass("active"))
}

function calendarContinue() {
    if ("leaving" == direction) { 
    	$(".date .direction .leaving").removeClass("active");
    	$(".date .direction .returning").addClass("active");
    	direction = "returning"
    } else {
  		$(".search_drawer .date .close_button").trigger("click");
  		console.log("closing");
  	}
}
$(function () {


	$(".date .direction .leaving, .date .direction .returning").bind("click", calendarDirection)
	for (var i = 0; i < 170; i++) {
	    var numberIsInArray = false;
	    var rand = generateRandomNumb(1, 12);
	    cellContents.push("£" + rand);
	}


	$.datepicker._defaults.onAfterUpdate = null;
    var datepicker__updateDatepicker = $.datepicker._updateDatepicker;
    $.datepicker._updateDatepicker = function (inst) {
        datepicker__updateDatepicker.call(this, inst);
        var onAfterUpdate = this._get(inst, 'onAfterUpdate');
        if (onAfterUpdate)
            onAfterUpdate.apply((inst.input ? inst.input[0] : null), [(inst.input ? inst.input.val() : ''), inst]);
    }
  
    var cur = -1
        , prv = -1;
    $('#calendar')
        .datepicker({
            numberOfMonths: 4
            , changeMonth: false
            , weekHeader: false
            , dayNames: false
            , firstDay: 1
            , minDate: 0
            , changeYear: false
            , showButtonPanel: true
            , beforeShowDay: function(a) {
                return $("#calendar").is(".single") ? [!0, a.getTime() == cur ? "date-range-selected" : ""] : [!0, a.getTime() >= Math.min(prv, cur) && a.getTime() <= Math.max(prv, cur) ? "date-range-selected" : ""]
            }
            ,onSelect: function(a, i, r) {
                console.log(a);
                var n = new Date(a);
                a = weekday[n.getDay()] + " " + n.getDate() + " " + shortmonth[n.getMonth()], n.toString() == now.toString() ? a = "Today" : console.log(n, now), "leaving" == direction ? (cur = new Date(i.selectedYear, i.selectedMonth, i.selectedDay).getTime(), saveTheDate.leaving = cur, $("#jrange input.singleB").val(a), $(".date .direction .leaving .value").html(a).addClass("validates"), "" != saveTheDate.returning ? prv = saveTheDate.returning : (prv = cur, $("td.ui-datepicker-current-day").removeClass("ui-datepicker-current-day"))) : (cur = new Date(i.selectedYear, i.selectedMonth, i.selectedDay).getTime(), saveTheDate.returning = cur, $("#jrange input.returnB").val(a), $(".date .direction .returning .value").html(a).addClass("validates"), $("#jrange").parent().removeClass("alert"), prv = "" != saveTheDate.leaving ? saveTheDate.leaving : cur)
            }
            ,onAfterUpdate: function(cur, prv) {
                var a = $(".ui-datepicker td a").width();
                $(".ui-datepicker td a, .ui-state-highlight").height(a), ("" == saveTheDate.leaving || "" == saveTheDate.returning) && ($("td.date-range-selected").removeClass("date-range-selected"), $("a.ui-state-active").parent().addClass("date-range-selected")), roundRange(), $('<button type="button" class="ui-datepicker-close ui-state-default ui-priority-primary ui-corner-all" data-handler="hide" data-event="click">Done</button>').appendTo($("#calendar .ui-datepicker-buttonpane")), updateDatePickerCells()
            }
        })
        .datepicker("setDate", null)
        .position({
            my: 'left top'
            , at: 'left bottom'
            , of: $('#jrange input')
        })
    updateDatePickerCells();
    $('#jrange input').on('focus', function (e) {
        var v = this.value
            , d;
        try {
            if (v.indexOf(' - ') > -1) {
                d = v.split(' - ');
                prv = $.datepicker.parseDate('mm/dd/yy', d[0]).getTime();
                cur = $.datepicker.parseDate('mm/dd/yy', d[1]).getTime();
            } else if (v.length > 0) {
                prv = cur = $.datepicker.parseDate('mm/dd/yy', v).getTime();
            }
        } catch (e) {
            cur = prv = -1;
        }
        $('#calendar').datepicker('refresh').show();
        if (cur > -1) {
            $('#calendar').datepicker('setDate', new Date(cur));
            console.log("1");
        } else {
            $('#calendar').datepicker('setDate', null).find(".date-range-selected").removeClass("date-range-selected, ui-datepicker-current-day");
            removeTodayHighlighting();
            console.log("2");
        }
        widthDate = $(".ui-datepicker td a").width();
        $(".ui-datepicker td a,.ui-state-highlight").height(widthDate);
    });
});