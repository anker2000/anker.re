var markerHandler = function() {
	
	function inputHandler(e) {
	
	}
	
	return {
		Init: function(elm) {
			
		}
	}
}();