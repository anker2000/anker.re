var tabNav = function() {
	var activeTab;
	var nav, options;
	function setupLinks() {
		nav.find("li").bind("click",function(e) {

			$(".journey input.active")[0].activeTab=$(this).index();

			nav.find("li").removeClass("active");
			$(this).addClass("active");
			
			// if ($(this).html().indexOf('Network')>-1) {
			// 	searchHandler.activateSearch($(".journey input.active")[0]);
			// }

			options.find("ul").removeClass("active");
			options.find("ul:nth-child("+($(this).index()+1)+")").addClass("active");
			setTimeout(function(options) {
				options.scrollTop(0);
			},300,options); // waiting for transition
		});
	}
	return {
		Init: function(elm) {
			nav = $(elm).find(".nav");
			options = $(elm).find(".options");
			nav.find("li:first-child").addClass("active");
			options.find("ul:first-child").addClass("active");
			setupLinks();
		}
	}
	
}();
$(".tabNav").each(function() {
	tabNav.Init(this);
})