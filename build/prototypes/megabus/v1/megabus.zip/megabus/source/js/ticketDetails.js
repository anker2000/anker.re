var ticketDetails = function() {
	function back(e) {
		console.log("back request from",e.target);
		if ($(e.target).hasClass("from")) {
			$(".journey input[tabindex=1]").trigger("focus");
		} else {
			$(".journey input[tabindex=2]").trigger("focus");
		}
		tripLockedIn = false;
		document.location.hash="#";
		updateMarkers();
		$(".journey .locations li:contains(Recent)").trigger("click");
	}
	return {
		Init: function() {
			$(".ticket_details").find(".to, .from").bind("click", back);
		}
	}
}();
$(function() {
	ticketDetails.Init();
})
