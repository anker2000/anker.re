var globalJSON;
var busStopFile = "eu-bus-stops.json?"+Math.random();
var journeyFile = "eu-journey.json?"+Math.random();

function getBusStops() {
	var jqxhr = $.getJSON( "feeds/"+busStopFile, {format: "json"}, function(data) {
		departure_data = data;

		globalJSON = data;
		// $(".outbound ul.travel_list").html(dataHandler(data));
		busStopHandler(data, { },'type');
	
	}).done(function() {
		// console.log( "second success" );
	})
	.fail(function(e) {
		console.log( "error",e );
	})

};
function getJourneys() {
	var jqxhr = $.getJSON( "feeds/"+journeyFile, {format: "json"}, function(data) {
		departure_data = data;

		globalJSON = data;
		// $(".outbound ul.travel_list").html(dataHandler(data));
		journeyHandler(data);
	
	}).done(function() {
		// console.log( "second success" );
	})
	.fail(function(e) {
		console.log( "error",e );
	})
}


function clone(obj) {
	if (null == obj || "object" != typeof obj) return obj;
	var copy = obj.constructor();
	for (var attr in obj) {
		if (obj.hasOwnProperty(attr)) copy[attr] = obj[attr];
	}
	return copy;
}