var apiKey = "AIzaSyCHh4oobxVPkxm0NuPSpusns3QNe9ZdJHU";
var map;
var tempMarkers = [];
var markers = [];
var infoCloseTimeout;
var activeInfo;
var zoomLevel = 7;
var busStops, journey; // Taffy vars
var poly;
var tripLockedIn = false;
var mapBounds;
var customStyles = [{"featureType":"administrative","elementType":"geometry","stylers":[{"visibility":"on"},{"color":"#cccccc"}]},{"featureType":"administrative","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"landscape","elementType":"geometry.fill","stylers":[{"visibility":"on"},{"color":"#eeeeee"}]},{"featureType":"landscape","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"geometry","stylers":[{"visibility":"off"}]},{"featureType":"poi","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"road","elementType":"geometry","stylers":[{"visibility":"simplified"},{"color":"#ffda86"}]},{"featureType":"road","elementType":"labels","stylers":[{"visibility":"off"}]},{"featureType":"water","elementType":"geometry.fill","stylers":[{"color":"#9edbf7"}]},{"featureType":"water","elementType":"labels","stylers":[{"visibility":"off"}]}];
var imageCitySelected = {
	url: 'img/maps_marker-city-selected.svg',
	size: new google.maps.Size(30, 30),
	origin: new google.maps.Point(0, 0),
	anchor: new google.maps.Point(15, 15)
};
var imageCityBig = {
	url: 'img/maps_marker-city-big.svg',
	size: new google.maps.Size(30, 30),
	origin: new google.maps.Point(0, 0),
	anchor: new google.maps.Point(15, 15)
};
var imageCitySmall = {
	url: 'img/maps_marker-city-small.svg',
	size: new google.maps.Size(30, 30),
	origin: new google.maps.Point(0, 0),
	anchor: new google.maps.Point(15, 15)
};
var imageEnRoute = {
	url: 'img/maps_marker-city-enroute.svg',
	size: new google.maps.Size(30, 30),
	origin: new google.maps.Point(0, 0),
	anchor: new google.maps.Point(15, 15)
}
var imageCityCluster = {
	url: 'img/maps_marker-cluster.svg',
	size: new google.maps.Size(30, 30),
	origin: new google.maps.Point(0, 0),
	anchor: new google.maps.Point(15, 15)
};
var imageBusStop = {
	url: 'img/maps_marker-busstop.svg',
	size: new google.maps.Size(50, 70),
	origin: new google.maps.Point(0, 0),
	anchor: new google.maps.Point(25, 60)
}
initMap();

	
function initMap() {
	if (navigator.geolocation) {
		navigator.geolocation.getCurrentPosition(createMap,error);
	} 
}
function busStopHandler(json, options,sortField) {
	if (typeof json == "undefined") {
		json = globalJSON;
		if (typeof json == "undefined") return false;
	}
	busStops = TAFFY(json);

	busStops(options).each(function(busStop) {
		if (busStop.type=="A") {
			var tempMarker = {
				position: {lat: busStop.latitude, lng: busStop.longitude},
				map: map,
				icon: imageCityBig,
				title: busStop.city,
				zIndex:2,
				type:busStop.type
		    };
		} else {
			var tempMarker = {
				position: {lat: busStop.latitude, lng: busStop.longitude},
				map: map,
				icon: imageCitySmall,
				title: busStop.city,
				zIndex:1,
				type:busStop.type
		    };
		}
		tempMarkers.push(tempMarker);
	});
	setTimeout(function() {
		updateMarkers();
		searchHandler.setupStations();
		hashChangeHandler.Init();
	},2000);
	google.maps.event.addListener(map, 'bounds_changed',boundsChangeHandler);
}
function boundsChangeHandler() {
	mapBounds=map.getBounds();
}
function updateMarkers() {
	console.log("map bounds",mapBounds);
	var journey = searchHandler.getJourney();
	if (markers.length>0) {
		clearMarkers();
	}

	var gridSize = 4;
	switch(map.zoom) {
		case 5:
			gridSize=2.4;
			break;
		case 6:
			gridSize=1.2;
			break;
		case 7:
			gridSize=0.4;
			break;
		case 8:
			gridSize=0.2;
			break;
	}

	var allMarkers = tempMarkers;
	var gridSection = [];
	var grid = [];

	//looping through each section of the globe grid and grouping cities within each section
	for (lng=-10.5;lng<=22;lng+=gridSize) {
		for (lat=36;lat<=61;lat+=gridSize) {
			gridSection = [];
			for (i=0;i<allMarkers.length;i++) {
				if ((allMarkers[i].position.lng >= lng && allMarkers[i].position.lng<lng+gridSize) && (allMarkers[i].position.lat >= lat && allMarkers[i].position.lat<lat+gridSize)) {
					gridSection.push(allMarkers[i]);
				}
			}
			if (gridSection.length>0) {
				grid.push(gridSection.splice(0));
			}
		}
	}
	
	for (i=0;i<grid.length;i++) {
		gridSection = grid[i].splice(0);
		if (gridSection.length>1 && map.zoom<8) {
			var groupLat = 0;
			var groupLng = 0;
			var avrLat = 0;
			var avrLng = 0;
			var bigCityCount=0;

			// going through the position of each city within group to find average coordinates/center point for the group 
			for (a=0;a<gridSection.length;a++) {
				avrLat += gridSection[a].position.lat;
				avrLng += gridSection[a].position.lng;
				if ((gridSection[a].title!=journey.begin && gridSection[a].title!=journey.end)) {
					if (gridSection[a].zIndex==2) {
						// if there's a big city within the group that becomes the center point for the group
						groupLat = gridSection[a].position.lat;
						groupLng = gridSection[a].position.lng;
						bigCityCount++;
					}
				} else { // if bus stop has been selected or is part of a selected journey
					var addGrid = [];
					if (gridSection[a].title==journey.begin) {
						gridSection[a].targetInput = $(".journey input[tabindex=1]");
					} else if (gridSection[a].title==journey.end) {
						gridSection[a].targetInput = $(".journey input[tabindex=2]");
					}
					addGrid.push(gridSection[a]);
					grid.push(addGrid);
					gridSection.splice(a,1);
					a--;
				}
			}

			// calculate average location if there's either no big cities within the group OR more than one big city
			if (bigCityCount!=1) {
				groupLat = avrLat/gridSection.length;
				groupLng = avrLng/gridSection.length
			}

			var clusterPosition = { lat: groupLat, lng: groupLng };

			var withinLat = (clusterPosition.lat>=mapBounds.H.H && clusterPosition.lat<=mapBounds.H.j); 
			var withinLng = (clusterPosition.lng<=mapBounds.j.H && clusterPosition.lng>=mapBounds.j.j);
			var markerDelay = 0;
			if (!withinLat || !withinLng) {
				markerDelay = 2000;
				console.log("not within bounds",clusterPosition);
			}
			setTimeout(function(position,title) {
				var clusterMarker = new google.maps.Marker({
					position: {lat: position.lat, lng: position.lng },
					map: map,
					icon: imageCityCluster,
					title: title,
			        labelClass: "labels", // the CSS class for the label
					zIndex:2,
			    });
				
				var groupWindow = new google.maps.InfoWindow({
					content: '<div class="labelHook">'+title+'</div>',
					disableAutoPan : true
				});
				
				groupWindow.open(map, clusterMarker);

				setTimeout(function() {
					$(".labelHook").each(function() {
						var thisHTML=$(this).html();
						$(this).parent().parent().parent().parent().html(thisHTML).addClass("groupLabel");
					})
				},100);
			    markers.push(clusterMarker);
			    google.maps.event.addListener(clusterMarker,'click',function() {
					setTimeout(clearMarkers,200);
					setTimeout(function() {
						map.setZoom(map.zoom + 1);
					},400,clusterMarker);
					map.panTo(new google.maps.LatLng(this.position.lat(), this.position.lng()));
				});
			},markerDelay, clusterPosition,gridSection.length.toString());
			

		} else {
			for (a=0;a<gridSection.length;a++) {
				if (gridSection[a].title==journey.begin) {
					gridSection[a].targetInput = $(".journey input[tabindex=1]");
				} else if (gridSection[a].title==journey.end) {
					gridSection[a].targetInput = $(".journey input[tabindex=2]");
				}
				

				var clusterPosition = { lat: groupLat, lng: groupLng };

				var withinLat = (gridSection[a].position.lat>=mapBounds.H.H && gridSection[a].position.lat<=mapBounds.H.j); 
				var withinLng = (gridSection[a].position.lng<=mapBounds.j.H && gridSection[a].position.lng>=mapBounds.j.j);
				var markerDelay = 0;
				if (!withinLat || !withinLng) {
					markerDelay = 3000;
				}

				setTimeout(function(thisGridSection) {
					var thisMarker = new google.maps.Marker(thisGridSection);
					markers.push(thisMarker);
					google.maps.event.addListener(thisMarker,'click',function(e) {
						if (typeof this.labelElm == "undefined") {
							this.labelElm = $('.cityLabel h3:contains("'+this.title+'")').parent().parent();
						}
						searchHandler.fillInCity(this);
						clearTimeout(this.timeout);
					});
					if ((thisGridSection.title==journey.begin || thisGridSection.title==journey.end)) {
						setTimeout(function(thisMarker,targetElm) {
							searchHandler.setElementFocus(targetElm);
							google.maps.event.trigger(thisMarker, "click");
							searchHandler.setElementFocus(targetElm);
						},300,thisMarker,thisGridSection.targetInput);
					}
					google.maps.event.addListener(thisMarker,'mouseover',function(e) {
						if (typeof this.labelElm == "undefined") {
							this.labelElm = $('.cityLabel h3:contains("'+this.title+'")').parent().parent();
						}
					});

					thisMarker.cityWindow = new google.maps.InfoWindow({
		  				content: '<div class="labelCityHook"><div class="labelbg"></div><div class="label'+thisGridSection.zIndex+'"><h3>'+thisGridSection.title+'</h3><a href="#/station_info/'+thisGridSection.title+'">Show stop details</a></div></div>',
		  				disableAutoPan : true
					});
					thisMarker.cityWindow.open(map, thisMarker);
					setTimeout(function(sourceMarker) { // timeout because of the delay of cityWindow.open()
						$('.labelCityHook h3:contains("'+sourceMarker.title+'")').each(function() {
							var thisHTML=$(this).parent().parent().html();
							var targetElm = $(this).parent().parent().parent().parent().parent().parent();

							if ($(".label1",$(this)).length>0) {
								targetElm.html(thisHTML).addClass("cityLabel").addClass("small");
							} else {
								targetElm.html(thisHTML).addClass("cityLabel");
							}
							targetElm.bind("mouseover",function() {
								if (typeof this.zIndex=="undefined") {
									this.zIndex = $(this).parent().css("z-index");
								}
								$(this).parent().css("z-index",100000);
								var journeyStart = searchHandler.getJourney().begin;
								if (typeof journeyStart == "undefined" || $(".journey input[tabindex=1]").hasClass("active")) return;
								drawJourney({ begin: journeyStart, end: this.marker.title });
								clearTimeout(this.timeout);
							});
							targetElm.bind("mouseout",function() {
								this.timeout = setTimeout(undrawJourney,100);
								$(this).parent().css("z-index",this.zIndex);
							})
							targetElm.bind("click",function(e) {
								if (e.target.tagName!=="A") google.maps.event.trigger(this.marker,"click",e);
							});
							targetElm[0].marker = sourceMarker;
						});
					},250, thisMarker)
				},markerDelay,gridSection[a])
			}
		}

	}
	// if (journey.begin && journey.end) {
	// 	drawJourney(journey);
	// }
}
function getCurrentBounds() {
	return map.getBounds(); 
}
function journeyHandler(json) {
	if (typeof json == "undefined") {
		json = globalJSON;
		if (typeof json == "undefined") return false;
	}
	journey = TAFFY(json);
}
var journeyMarkers = [];
function drawJourney(journeyData) {
	if (typeof poly != "undefined") poly.setMap(null);
	

	var lineSymbol = {
		path: 'M 0,-1 0,1',
		strokeOpacity: 1,
		scale: 3,
		strokeWeight: 2.2,
		strokeColor: '#aaaaaa',
	};

	poly = new google.maps.Polyline({
		
		strokeOpacity: 0,
		strokeWeight: 2,
	    icons: [{
			icon: lineSymbol,
			offset: '0',
			repeat: '15px'
	    }],
	    zIndex: 10,
		map: map,
	});

	var startLabel = $('.cityLabel h3:contains("'+journeyData.begin+'")').parent().parent();
	var endLabel = $('.cityLabel h3:contains("'+journeyData.end+'")').parent().parent();

	var path = [startLabel[0].marker.getPosition()];
	// console.log("finding journeys from",journeyData.begin,"to",journeyData.end);


	
	journey({from:journeyData.begin}, {to:journeyData.end }).each(function(journey) {
		if (typeof journey.stops!="undefined") {
			for (i=0;i<journey.stops.length;i++) {
				busStops({city:journey.stops[i].city}).each(function(city) {
					var tempJourneyMarker = {
						position: {lat: city.latitude, lng: city.longitude},
						map: map,
						icon: imageEnRoute,
						title: city.city,
						zIndex:3,
						type:city.type
				    };
				    var journeyMarker = new google.maps.Marker(tempJourneyMarker);
				    journeyMarkers.push(journeyMarker);
				    path.push(journeyMarker.getPosition());
					console.log("create temporary markers on top of the others",city.latitude,city.longitude);
				});
			}
		}
		
	});
	path.push(endLabel[0].marker.getPosition());
	console.log(path);
 	poly.setPath(path);
}
function repositionMapToJourney() {
	// var bounds = {
	// 	H: {
	// 		H
	// 	}
	// }
	// (gridSection[a].position.lat>=mapBounds.H.H && gridSection[a].position.lat<=mapBounds.H.j); 
	// (gridSection[a].position.lng<=mapBounds.j.H && gridSection[a].position.lng>=mapBounds.j.j);

	// map.fitBounds(bounds);
}
function undrawJourney() {
	if (typeof poly != "undefined") poly.setMap(null);
	for (var i = 0; i < journeyMarkers.length; i++) {
		journeyMarkers[i].setMap(null);
	}
}
function mapZoomHandler() {
	console.log("zoom level",map.zoom);
	searchHandler.setElementFocus($(".journey input[tabindex=1]"));
	clearMarkers();
	setTimeout(updateMarkers,500);
}
function createMap(currentLocation) {
	console.log("current location",currentLocation);
	map = new google.maps.Map(document.getElementsByClassName('bgmap')[0], {
		center: {lat: currentLocation.coords.latitude, lng: currentLocation.coords.longitude},
		zoom: zoomLevel,
		styles: customStyles,
		disableDefaultUI: false,
		mapTypeControl: false,
		scaleControl: true,
		scrollwheel: false,
	});
	getBusStops();
	getJourneys();
	google.maps.event.addListener(map, 'zoom_changed', mapZoomHandler);
	map.addListener("click", closeDrawers);
	map.addListener("dragstart", closeDrawers);
	map.addListener("dblclick", closeDrawers);

	// map.addListener("bounds_changed", closeDrawers);
}
function error(er) {
	console.log("error",er);
	console.log("defaulting to Huge London office location");
	var location = {};
	location.coords = {}
	location.coords.latitude=51.521803399999996;
	location.coords.longitude=-0.0850481;
	createMap(location);
}
function clearMarkers() {
	setMapOnAll(null);
	markers = [];
}
function setMapOnAll(map) {
	// console.log("deleting "+markers.length+" markers");
	for (var i = 0; i < markers.length; i++) {
		markers[i].setMap(map);
	}
}
function openStationInfo(name) {
	$(".station_info").addClass("expanded");
	busStops({city: name}).each(function(busStop) {

		$(".station_info .active").removeClass("active");
		$(".station_info .stations ul").html(" ")

		if (typeof busStop.stations!="undefined") {

			$(".station_info .stations").addClass("active");

			for (i=0;i<busStop.stations.length;i++) {
				var li = document.createElement("LI");
				li.innerHTML=name+", "+busStop.stations[i].city;
				li.addEventListener("click", function() {
					openStationMap(busStop);
				})
				$(".station_info .stations ul").append(li);
			}
		} else {
			openStationMap(busStop)
		}
	});
}
var station_marker;
function openStationMap(busStop) {
	$(".station_info .active").removeClass("active");
	$(".station_info .info").addClass("active");
	var station_map = new google.maps.Map(document.getElementsByClassName('stationmap')[0], {
		center: {lat: busStop.latitude, lng: busStop.longitude},
		zoom: 16,
		styles: customStyles,
		disableDefaultUI: true,
		mapTypeControl: false,
		scaleControl: false
	});
	if (typeof station_marker!="undefined") station_marker.setMap(null);

	station_marker = new google.maps.Marker({
		position: {lat: busStop.latitude, lng: busStop.longitude},
		map: station_map,
		icon: imageBusStop,
		title: busStop.city,
        labelClass: "labels", // the CSS class for the label
		zIndex:2,
    });
	
}
function closeDrawers() {
	var target=document.location.hash.replace("#","");
	if (target.indexOf("/ticket_details/")==-1) {
		setTimeout(function() {
			$(".station_info .active").removeClass("active");
		},400);
		$(".expanded").removeClass("expanded");
		document.location.hash="";
	}
}


