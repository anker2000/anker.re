var searchHandler = function() {
	var elementInFocus;
	var stationStart, stationEnd;
	function inputHandler(e) {
		var searchFor = $(e.target).val();
		if (typeof e.altKey != "undefined") $(".tabNav.locations .nav li:contains(Network)").trigger("click");

		$(".results.network").html(" ");
		busStops([{city:{"likenocase":searchFor}},{country:{"likenocase":searchFor}}]).order("country,city").each(function(busStop) {
			var stop = document.createElement("li");
			stop.innerHTML = "<p>"+busStop.city+"</p>";
			$(".results.network").append(stop);
			$(stop).unbind("click");
			$(stop).bind("click",resultsClickHandler);
		});
		checkIfSubmittable();
	}
	function resultsClickHandler(e) {
		
		var sourceElm = parentWithTagName(e.target,"li");
		var cityName = $(sourceElm).find("p").html();
		var targetLabel = $('.cityLabel h3:contains("'+cityName+'")').parent().parent();
		// $(elementInFocus).val(cityName);
		if ($(elementInFocus).attr("tabindex")==1) {
			stationStart=cityName;
		} else {
			stationEnd = cityName;
		}
		if (typeof targetLabel[0]=="undefined") { //update Markers to pull city out of cluster
			updateMarkers();
		} else {
			console.log("triggering click", e);
			google.maps.event.trigger(targetLabel[0].marker, "click");
		}
		$(".journey").removeClass("expanded");
		$(".ticket_details .from").html(stationStart);
		$(".ticket_details .to").html(stationEnd);
	}
	function expandDrawer(e) {
		$(elementInFocus).removeClass("active");
		elementInFocus = e.target;
		$(elementInFocus).addClass("active");
		$(".journey").addClass("expanded");
		if (typeof elementInFocus.activeTab !="undefined") {
			$(".journey .locations ul.nav").find("li:nth-child("+(elementInFocus.activeTab+1)+")").trigger("click");
		} else {
			if ($(elementInFocus).attr("tabindex")==1) {
				$(".journey .locations ul.nav").find("li:nth-child(1)").trigger("click");
			} else {
				$(".journey .locations ul.nav").find("li:nth-child(2)").trigger("click");
			}
		}
		// if ($(".journey .locations .active").html()=="Network") {
		// 	console.log("reset search");
		// 	searchHandler.activateSearch($(".journey input.active")[0]);
		// }
	}
	function checkIfSubmittable() {
		if (typeof stationStart != "undefined" && typeof stationEnd!= "undefined") {
			$(".journey").addClass("submittable");
			repositionMapToJourney();
		} else {
			$(".journey").removeClass("submittable");
		}
	}
	return {
		activateSearch: function(obj) {
			$(obj).focus();
			var mockEvent = { target: obj };
			inputHandler(mockEvent);
		},
		setElementFocus: function(elm) {
			elementInFocus=elm[0];
			$(".journey input[type=search]").removeClass("active");
			elm.addClass("active");
		},
		setupStations: function() {
			busStops().order("country,city").each(function(busStop) {
				var stop = document.createElement("li");
				stop.innerHTML = busStop.city;
				$(".results.network").append(stop);
			});
		},
		Init: function() {
			$(".journey input[type=search]").each(function() {
				if ($(this).hasClass("active")) elementInFocus=this;
				$(this).bind("keyup",inputHandler);
				$(this).bind("focus",expandDrawer);
			});
			$(".options .results li").unbind("click").bind("click",resultsClickHandler);
		},
		getJourney: function() {
			return { begin: stationStart, end: stationEnd };
		},
		fillInCity: function(obj) {
			if (typeof elementInFocus.marker != "undefined") {
				if (elementInFocus.marker.type=="A") {
					targetIcon = imageCityBig;
				} else {
					targetIcon = imageCitySmall;
				}
				elementInFocus.marker.setIcon(targetIcon)
				elementInFocus.marker.labelElm.removeClass("selected");
			}
			elementInFocus.marker = obj;
			$(elementInFocus).val(obj.title);
			// obj.setAnimation(google.maps.Animation.DROP);
			obj.setIcon(imageCitySelected);
			obj.labelElm.addClass("selected");
			if (elementInFocus.getAttribute("tabindex")==1) {
				stationStart = obj.title;
				$(elementInFocus).removeClass("active");
				elementInFocus=$(".journey input[tabindex=2]")[0];
				$(elementInFocus).addClass("active");
			} else {
				stationEnd = obj.title;
				// $(elementInFocus).removeClass("active");
				// elementInFocus=$("input[tabindex=1]")[0];
				// $(elementInFocus).addClass("active");
			}
			checkIfSubmittable();
			// if (typeof stationStart != "undefined" && typeof stationEnd!= "undefined") {
			// 	drawJourney(searchHandler.getJourney());
			// }
		}
	}
}();
searchHandler.Init();
