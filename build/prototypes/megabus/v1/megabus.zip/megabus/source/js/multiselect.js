var multiselect = function() {
	function updateLabel(selectbox, init) {
		var label = "Showing "+ selectbox.selected.length + " carriers";
		if (selectbox.items.length == selectbox.selected.length) {
			label = "Showing all carriers";
		} else if (selectbox.selected.length == 1) {
			label = "Showing 1 carrier";
		}
		$(selectbox).find(".multiselect-field").html(label);
	}
	function setInitalCheckState(selectbox) {
		for (i=0; i<selectbox.selected.length; i++) {
			$(".multiselect-list li:nth-child("+(parseInt(selectbox.selected[i])+1)+") input[type=checkbox]").prop("checked",true);
		}
	}
	function getChecked(selectbox) {
		var tempChecked = [];
		$(selectbox).find("input[type=checkbox]").each(function() {
			if ($(this).prop("checked")) {
				tempChecked.push($(this).parent().index());
			}
		});
		selectbox.selected = tempChecked;
		console.log("currently checked",selectbox.selected);
	}
	function setupListeners(selectbox) {
		$(selectbox.items).find("input[type=checkbox]").bind("change",function() {
			getChecked(selectbox);
			updateLabel(selectbox);
		});
		$(selectbox).find(".multiselect-field").bind("click",function() {
			$(this).parent().toggleClass("open");
		});
	}
	return {
		Init: function() {
			$(".multiselect").each(function() {
				this.selected = $(this).data("initially-selected").split(",");
				this.items = $(this).find(".multiselect-list li");
				

				updateLabel(this);
				setInitalCheckState(this);
				setupListeners(this);
			});
		}
	}
}();
multiselect.Init();
