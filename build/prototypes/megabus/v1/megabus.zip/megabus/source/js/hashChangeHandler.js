var hashChangeHandler = function() {
	
	function setupLinks() {
		
	}
	function change() {
		ticketLockedIn = false;
		var target=document.location.hash.replace("#","");
		console.log("location hash",target);
		if (target.indexOf("/station_info/")>-1) {
			target = target.replace("/station_info/","");
			openStationInfo(target);
		}
		if (target.indexOf('/ticket_details/')>-1) {
			ticketLockedIn=true;
			$(".ticket_details").addClass("enabled");
			window.requestAnimationFrame(clearMarkers);
		} else {
			$(".ticket_details").removeClass("enabled");
		}
	}
	return {
		Init: function() {
			$(window).bind("hashchange",change);
			change();
		}
	}
	
}();

